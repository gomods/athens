package mod

func Hello() {}
