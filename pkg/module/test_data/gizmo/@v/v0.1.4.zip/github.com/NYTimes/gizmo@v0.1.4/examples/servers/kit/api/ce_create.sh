#!/bin/sh

gcloud service-management deploy ./service.pb ./ce_config.yaml
