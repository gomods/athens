/*
Package web contains a handful of very useful functions for parsing types from request queries and payloads.
*/
package web
