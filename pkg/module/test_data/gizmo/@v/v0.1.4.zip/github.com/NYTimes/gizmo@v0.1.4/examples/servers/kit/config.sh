export MOST_POPULAR_TOKEN="your-most-popular-token";
export SEMANTIC_TOKEN="your-semantic-token";
