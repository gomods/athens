## `sqs-sub`
* example of a small daemon process consumes an Amazon SQS queue via a `gizmo/pubsub.SQSPublisher`. 

### The config in this example is loaded via a local JSON config file into the default `gizmo/config.Config` struct.
