## `cli-sns-pub` 
* example of a simple CLI utility that emits an message to AmazonSNS via a `gizmo/pubsub.SNSPublisher`. 

### The config in this example is loaded via environment variables and it utilizes the default `gizmo/config.Config`. Before running, fill in some AWS credentials and `source` the local '.env' file. 
