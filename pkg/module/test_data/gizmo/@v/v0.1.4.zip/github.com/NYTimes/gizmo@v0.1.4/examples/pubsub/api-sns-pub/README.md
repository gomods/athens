# `api-sns-pub` 
* example mixing `gizmo/server.SimpleServer`, `gizmo/server.JSONService` and `gizmo/pubsub.SNSPublisher`. 
* JSON API will accept a message and then publish it to an Amazon SNS topic.

### The config in this example is loaded via a local JSON file and the default `gizmo/config.Config` struct.
