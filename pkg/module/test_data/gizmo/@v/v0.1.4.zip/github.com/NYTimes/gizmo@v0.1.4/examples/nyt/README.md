## This is a simple client for a couple public New York Times APIs. The client and its related types are used throughout the gizmo toolkit examples.
