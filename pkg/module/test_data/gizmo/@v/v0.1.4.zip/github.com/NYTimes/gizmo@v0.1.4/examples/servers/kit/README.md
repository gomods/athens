## `kit`
* example using a `gizmo/server/kit.Service`. 
* one endpoint will serve JSON of the most popular NYT articles and another will serve JSON listing recent articles in The New York Times about 'cats'.
* this service is also available via gRPC.
