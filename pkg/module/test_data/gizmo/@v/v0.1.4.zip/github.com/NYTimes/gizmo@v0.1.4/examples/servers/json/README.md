## `json`
* example using a `gizmo/server.JSONService` with a `gizmo/server.SimpleServer`. 
* one endpoint will serve JSON of the most popular NYT articles and another will serve JSON listing recent articles in The New York Times about 'cats'.

### The config in this example is loaded via a local JSON file and a custom config struct that is composed of a `gizmo/config.Server` struct.
